
USAGE :: bash ssf2conll.sh file/directory output file log file"

Input Data can either be a file or a folder.

The data should be in ssf formatt::

1	((	NP	fs name='NP' drel='rel:head'

1.1	the	DET	fs af='the,det,,,,,,,' name='the'

1.2	boy	NN	fs af='boy,n,,,,,,,' name='boy'

	))		

Dependencies ::

1. headcomputation
2. vibhakticomputation

Set the environment variable ssf2conll to conll converter folder in ~/.bashrc as export ssf2conll="PATH OF CONLL CONVERTER FOLDER"
