#perl $setu/bin/sl/vibhakticomputation/vibhakticomputation.pl --path=$setu/bin/sl/vibhakticomputation -i $1
perl $ssf2conll/dependencies/vibhakticomputation-2.3.4/vibhakticomputation.pl --path=$ssf2conll/dependencies/vibhakticomputation-2.3.4/ -i $1 --keep=$2
