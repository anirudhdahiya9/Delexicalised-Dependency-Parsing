perl $setu/bin/sys/common/printinput.pl $1 > headcomputationinput
perl $setu/bin/sl/headcomputation/headcomputation.pl --path=$setu/bin/sl/headcomputation --input=headcomputationinput
