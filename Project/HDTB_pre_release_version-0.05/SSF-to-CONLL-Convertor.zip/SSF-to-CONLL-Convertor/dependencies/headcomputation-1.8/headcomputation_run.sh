#perl $setu/bin/sl/headcomputation/headcomputation.pl --path=$setu/bin/sl/headcomputation -i $1

perl $ssf2conll/dependencies/headcomputation-1.8/headcomputation.pl --path=$ssf2conll/dependencies/headcomputation-1.8/ -i $1
