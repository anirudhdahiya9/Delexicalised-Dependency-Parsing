perl $setu/bin/sys/common/printinput.pl $1 > vibhakticomputationinput
perl $setu/bin/sl/vibhakticomputation/vibhakticomputation.pl --path=$setu/bin/sl/vibhakticomputation --input=vibhakticomputationinput
