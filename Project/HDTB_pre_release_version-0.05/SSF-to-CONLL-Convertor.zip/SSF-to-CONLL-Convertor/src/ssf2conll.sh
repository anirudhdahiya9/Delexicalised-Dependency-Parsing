#!/usr/bin/bash

if [[ $# -eq 3 ]]; then
	echo -n "" > $2
else
	echo "Please specify the required valid arguments as :: <input file|directory> <log file> <annotation type>"
	exit 1
fi

INPUT=$1 
LOGFILE=$2
annotationType=$3
TEMP="head_vib.temp"

if [[ -d $INPUT ]]; then
	for input in $(find $INPUT -name '*' ); 
	do
		if [[ -f $input ]];then
			echo -n "" > $TEMP
			echo $input >> $LOGFILE
			if [[ $annotationType == "inter" ]];then
			python $ssf2conll/src/run_dependencies.py $input $TEMP $LOGFILE
			python $ssf2conll/src/ssfToConll.py --input-file $TEMP --output-file $input --log-file $LOGFILE --annotation $annotationType
			elif [[ $annotationType == "intra" ]]; then
			cat $input > $TEMP
			python $ssf2conll/src/ssfToConll.py --input-file $TEMP --output-file $input --log-file $LOGFILE --annotation $annotationType
			else
				echo 'Type of annotation not defined. Exiting now!'
				exit
			fi
		fi
	done
else
	echo $INPUT >> $LOGFILE
	if [[ $annotationType == "inter" ]];then
		python $ssf2conll/src/run_dependencies.py $INPUT $TEMP $LOGFILE
		python $ssf2conll/src/ssfToConll.py --input-file $TEMP --output-file $INPUT --log-file $LOGFILE --annotation $annotationType
	elif [[ $annotationType == "intra" ]]; then
		cat $INPUT > $TEMP
		python $ssf2conll/src/ssfToConll.py --input-file $TEMP --output-file $INPUT --log-file $LOGFILE --annotation $annotationType
	else
		echo 'Type of annotation not defined. Exiting now!'
			exit
	fi
fi

if [[ -f $TEMP ]];then
	rm $TEMP
fi

echo "Input files have been modified in-place. Check them for conll content!"
